/**
 * Created with IntelliJ IDEA.
 * User: 黄川
 * Date Time: 2014/12/2615:18
 * 核心服务器配置文件
 */
//部署位置IP或服务名称
const HOST = '192.168.2.120';

//监听端口
const PORT = '1306';

//资源文件端口
const RESPORT = '80';

//tailor服务地址
const BASEPATH = "http://" + HOST + ":" + PORT + "/tailor/";

//资源文件地址
const BASERES = "http://" + HOST + ":" + RESPORT + "/res/";

const debuginfo = {
    flag: true,//调试模式----部署时请改为false
    printflag: true,//打印模式
    TempPath:"d:/temp/",//每次请求都会将请求内容保证到这个目录
    rewritedTempFile:false//同一地址产生的临时文件是否覆盖
};