﻿/**
 * 核心工具包
 */

/**
 * 记录当前页面是否需要快速返回
 * setReturnUrlStatus默认true 需要记录
 * 如不需要记录请在js顶部声明var setReturnUrlStatus=false;
 * 获取快速返回地址  application.get('backurl');
 */
var setReturnUrlinit=function(){
    var status=true;
    try{
        status = setReturnUrlStatus  ? true : false;
    }catch (e){}
    print(status?'当前页面需要记录以作快速返回地址':'不需要记录');
    if(status){
        var request = fetcher.request;
        var backurl = request.url;
        print("backurl:"+backurl)
        application.set('backurl', backurl);
    }
}
setReturnUrlinit();


/**
 * 打印信息
 * @param msg 必须
 */
function print(args) {
    if(debuginfo.printflag){
        if (typeof args == "string") {
            println(args);
        } else {
            println(JSON.stringify(args));
        }
    }
}

/**
 * 服务器直接返回页面内容
 */
var server=new function(){
    /**
     * 弹出信息，确认后，跳转到url；
     * @param url 必选
     * @param alertmsg 可选
     */
    this.locationUrl=function(url,alertmsg) {
        tailor.contentType = "text/html;charset=utf-8;";
        if(alertmsg==undefined){
            tailor.setTextResult("<script>window.location.href='" + url + "';</script>");
        }else{
            tailor.setTextResult("<script>alert('"+alertmsg+"');window.location.href='" + url + "';</script>");
        }
    };
    /**
     * 弹出信息，确认后，返回前一页面；
     * @param alertmsg 必须
     */
    this.locationHistoryBack=function(alertmsg) {
        tailor.contentType = "text/html;charset=utf-8;";
        tailor.setTextResult("<script>alert('"+alertmsg+"');history.back();</script>");
    };
    /**
     * 返回text
     * @param text
     */
    this.setTextResult=function(text){
        tailor.contentType = "text/text;charset=utf-8;";
        tailor.setTextResult(text);
    };
    /**
     * 返回json
     * @param text
     */
    this.setJsonResult=function(args){
        tailor.contentType = "text/json;charset=utf-8;";
        tailor.setTextResult(JSON.stringify(args));
    };
    /**
     * 返回html
     * @param text
     */
    this.setHtmlResult=function(text){
        tailor.contentType = "text/html;charset=utf-8;";
        tailor.setTextResult(text);
    };
};




var unEscapeJson=new function(){
    /**
     * 核心
     * @param data
     * @returns {{}}
     */
    function unEscape(data){
        var temp_json = {};
        for (var i = 0; i < data.length; i++) {
            var temp_text = data[i];
            var key = temp_text.substring(0, temp_text.indexOf("="));
            var val = temp_text.substring(temp_text.indexOf("=") + 1, temp_text.length);
            temp_json[key] = val;
        }
        return temp_json;
    }
    /**
     * 解码POST参数并转换成JSON字符串
     * @param request 需要解码的字符串所在的request
     * @return {String} 解码后的JSON字符串
     */
    this.post=function(request) {
        var postData = urlDecoder(request.postData, "utf-8").split("&");
        return unEscape(postData);
    };
    /**
     * @param str 需要解码的字符串
     * @return {String} 解码后的JSON字符串
     */
    this.str=function(str) {
        var postData = str.split("&");
        return unEscape(postData);
    };
    /**
     * @param url 需要解码的url地址
     * @return {String} 解码后的JSON字符串
     */
    this.url=function(url){
        url = url.substring(url.indexOf("?") + 1, url.length);
        var postData = urlDecoder(url, "utf-8").split("&");
        return unEscape(postData);
    };
};


var fetch=new function(){
    var oDOMParser = new DOMParser();

    /**
     * 将本次请求的内容存入文件中
     * @param text
     */
    function debugSaveFile(text){
        if (debuginfo.flag) {
            var url = fetcher.request.url;
            try {
                url = url.replace(/ /g, ".").replace(/:/g, ".").replace(/\//g, ".").replace(/\?/g, ".");
            } catch (e) {
                url = "Error文件名替换出错" + new Date().toTimeString();
            }
            if(debuginfo.rewritedTempFile){
                saveFile(debuginfo.TempPath + url + ".html", text);
            }else{
                saveFile(debuginfo.TempPath + new Date().getTime()+"_BY_"+ url +".html", text);
            }
        }
    }
    /**
     * 返回页面的text
     * @param request
     * @param encoding
     * @returns {Function|string|*}
     */
    this.text=function(request, encoding){
        var oWebResponse = fetcher.fetchText(request, encoding);
        debugSaveFile(oWebResponse.text);
        return oWebResponse.text;
    };
    /**
     * 返回页面Dom
     * @param request
     * @param encoding
     * @returns {HTMLDocument}
     */
    this.dom=function(request, encoding){
        var oWebResponse = fetcher.fetchText(request, encoding);
        debugSaveFile(oWebResponse.text);
        var dom = oDOMParser.parseFromString(oWebResponse.text, "text/html")
        return dom;
    };

    /**
     *返回地址重定向地址与页面text
     * @param request
     * @param encoding
     * @returns {{locationurl: url, restext: string}
    */
    this.location=function(request, encoding){
        request.redirectable = false;
        var oWebResponse = fetcher.fetchText(request, encoding);
        var location = oWebResponse.get("Location");
        var text= oWebResponse.text;
        debugSaveFile(oWebResponse.text);
        return {locationurl: location, restext:text};
    };
    /**
     * 获取xml类型页面的Dom
     * @param request
     * @param encoding
     * @returns {HTMLDocument}
     */
    this.xml=function(request, encoding){
        var oWebResponse = fetcher.fetchText(request, encoding);
        var szText= oWebResponse.text;
        debugSaveFile(szText);
        var oDocument = oDOMParser.parseFromString(szText, "text/xml")
        return oDocument;
    };
};

var formpage=new function(){
    /**
     * 根据表单返回隐藏内容
     * @param formdom
     * @returns {string}
     */
    this.hiddenInput=function(formdom){
        var html = "";
        var input = formdom.getElementsByTagName("input");
        for (var i = 0; i < input.length; i++) {
            var that = input[i];
            if (that.getAttribute("type") == "hidden") {
                html += that.outerHTML;
            }
        }
        return html;
    };
    /**
     * 返回该form的所有input
     * @param formdom
     * @returns {string}
     */
    this.allInput=function(formdom){
        var html = "";
        var input = formdom.getElementsByTagName("input");
        for (var i = 0; i < input.length; i++) {
            var that = input[i];
            if(that.hasAttribute("class")){
                that.removeAttribute("class");
            }if(that.hasAttribute("tabindex")){
                that.removeAttribute("tabindex");
            }if(that.hasAttribute("style")){
                that.removeAttribute("style");
            }if(that.hasAttribute("onkeyup")){
                that.removeAttribute("onkeyup");
            }if(that.hasAttribute("onblur")){
                that.removeAttribute("onblur");
            }if(that.hasAttribute("autocomplete")){
                that.removeAttribute("autocomplete");
            }if(that.hasAttribute("onclick")){
                that.removeAttribute("onclick");
            }
            html += that.outerHTML;
        }
        return html;
    };
    /**
     * 根据表单返回select所有内容
     * @param formdom
     * @returns {string}
     */
    this.select=function(formdom){
        var html = "";
        var input = formdom.getElementsByTagName("select");
        for (var i = 0; i < input.length; i++) {
            var that = input[i];
            html += that.outerHTML;
        }
        return html;
    };

    /**
     * 获得单选框的值
     * @param doc
     * @param radioName
     * @returns {*}
     */
    this.getRadioValue=function(doc, radioName) {
        var obj = doc.getElementsByName(radioName);
        if (null != obj && undefined != obj) {
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].checked) {
                    return obj[i].value;
                }
            }
        } else {
            return "";
        }
    }

    /**
     * 设定单选框的值
     * @param doc
     * @param radioName
     * @param newValue
     */
     this.setCheckedValue=function(doc, radioName, newValue) {
        if (!radioName)
            return;
        var radios = doc.getElementsByName(radioName);
        for (var i = 0; i < radios.length; i++) {
            radios[i].checked = false;
            if (radios[i].value == newValue.toString()) {
                radios[i].checked = true;
            }
        }
    };

};


var unObjToUrl=new function(){
    function toQueryPair(key, value) {
        if (typeof value == 'undefined'){
            return key;
        }
        return key + '=' + encodeURIComponent(value === null ? '' : String(value));
    };
    this.topost=function(obj){
        var ret = [];
        for(var key in obj){
            key = encodeURIComponent(key);
            var values = obj[key];
            if(values && values.constructor == Array){//数组
                var queryValues = [];
                for (var i = 0, len = values.length, value; i < len; i++) {
                    value = values[i];
                    queryValues.push(toQueryPair(key, value));
                }
                ret = ret.concat(queryValues);
            }else{ //字符串
                if(!("merge"==key||"properties"==key||"_propertiesGenerator"==key)){
                    ret.push(toQueryPair(key, values));
                }
            }
        }
        return ret.join('&');
    };
}

/**
 * 通过className获取dom节点
 * @param n
 * @param dom
 * @returns {Array}
 */
function getElementsByClassName(n, dom) {
    var classElements = [], allElements = dom.getElementsByTagName('*');
    for (var i = 0; i < allElements.length; i++) {
        if (allElements[i].className == n) {
            classElements[classElements.length] = allElements[i];
        }
    }
    return classElements;
}

/**
 * 根据url地址获取该地址下的session cookie
 * @param url 必选  支持模糊匹配
 * @returns {string}
 */
function getSession(url) {
    var szSession = "";
    var oNameValueCollection = globalSession.getHttpCookie(url);
    for (var i = 0; i < oNameValueCollection.count; i++) {
        var szKey = oNameValueCollection.getKey(i);
        var szValue = oNameValueCollection[szKey];
        if (szSession == "") {
            if (typeof szValue != 'string') {
                szSession += szKey + "=" + szValue[0];
            } else {
                szSession += szKey + "=" + szValue;
            }
        } else {
            if (typeof szValue != 'string') {
                szSession += "; " + szKey + "=" + szValue[0];
            } else {
                szSession += "; " + szKey + "=" + szValue;
            }
        }
    }
    return szSession;
}

/**
 * 去除A标签的连接
 * @param dom
 * @returns {*}
 */
function removeA_href(dom) {
    var el = dom.getElementsByTagName('a');
    for (var i = 0; i < el.length; i++) {
        el[i].setAttribute("href", "#");
        el[i].setAttribute("rewrited", "false");
        el[i].setAttribute("target", "");
    }
    return dom;
}
/**
 * 修正Embed视频标签大小
 * @param dom
 * @returns {*}
 */
function replaceEmbed(dom) {
    var el = dom.getElementsByTagName('embed');
    for (var i = 0; i < el.length; i++) {
        el[i].setAttribute("height", "auto");
        el[i].setAttribute("width", "100%");
        el[i].style.width = '100%';
        el[i].style.height = 'auto';
    }
    return dom;
}
/**
 * 去除图片
 * @param dom
 * @returns {*}
 */
function removeImg(dom) {
    var el = dom.getElementsByTagName('img');
    for (var i = 0; i < el.length; i++) {
        var _el = el[i].parentNode;
        if (_el) {
            _el.removeChild(el[i]);
        }
    }
    return dom;
}
/**
 * 修正图片标签大小
 * @param dom
 * @returns {*}
 */
function replacImg(dom) {
    var img = dom.getElementsByTagName("img");
    var len = img.length;
    for (var i = 0; i < len; i++) {
        img[i].setAttribute("width", "100%");
        img[i].setAttribute("height", "auto");
        img[i].style.width = "100%";
        img[i].style.height = "auto";
        img[i].setAttribute("hspace", "0");
    }
    return dom;
}



//将字符串转换为unicode字符串
function getUnicodeString(sstr) {
    unicodestr = "";
    for (i = 0; i < sstr.length; i++) {
        unicodestr = unicodestr + sstr.charCodeAt(i) + ";";
    }
    return unicodestr;

}

/**
 * 获取当前时间
 * @returns {string}
 * @constructor
 */
function TimeNow() {
    var d, s = "&Time=";
    var c = ":";
    d = new Date();
    s += d.getHours() + c;
    s += d.getMinutes() + c;
    s += d.getSeconds() + c;
    s += d.getMilliseconds();
    return (s);
}
function trimAll(s1) {
    return s1.replace(/ /g, "");
}
function allTrim(str) {
    if (str != "" | str != null) {
        return str.replace(/(^\s*)|(\s*$)/g, "");
    }
}
function clearrn(str) {
    if (str != "" | str != null) {
        reg = /\n/g;
        var szTemp = str.replace(reg, "");
        reg = /\r/g;
        szTemp = szTemp.replace(reg, "");
        return szTemp;
    } else {
        return str;
    }
}
/*******************************************************************************
 * 名称: getCurrentTime
 * 功能: 取得当前时间
 * 输入: 无
 * 输出: 无
 * 返回: String
 ******************************************************************************/
function getCurrentTime() {
    var oNow = new Date()
    var hours = oNow.getHours()
    var minutes = oNow.getMinutes()
    var seconds = oNow.getSeconds()
    var timeValue = hours
    timeValue += ((minutes < 10) ? ":0" : ":") + minutes
    timeValue += ((seconds < 10) ? ":0" : ":") + seconds
    return timeValue
};
function getCurrentTimeAndRandom() {
    return getCurrentTime() + Math.random();
};
/**
 * 清除script标签
 * @param dom
 * @param nsStr
 */
function removeScripts(dom, nsStr) {
    var xpath = ".//NS:SCRIPT";
    if (null == nsStr || nsStr.isEmpty()) {
        nsStr = "";
        xpath = ".//SCRIPT";
    }
    var oScripts = dom.evaluate(xpath, dom, nsStr.trim(), 0);
    if (oScripts) {
        for (var i = 0; i < oScripts.length; i++) {
            var oScript = oScripts.item(i);
            oScript.parentNode.removeChild(oScript);
        }
    }
}
/******************** string 的相关操作扩展 ****************************/
String.prototype.isEmpty = function () {
    return /^\s*$/.test(this);
}
String.prototype.trim = function () {
    return this.replace(/(^\s*)|(\s*$)/g, "");
}
String.prototype.ltrim = function () {
    return this.replace(/(^\s*)/g, "");
}
String.prototype.rtrim = function () {
    return this.replace(/(\s*$)/g, "");
}
String.prototype.replaceAll = function (s1, s2) {
    return this.replace(new RegExp(s1, "gm"), s2);
}
String.prototype.endWith = function (str) {
    if (str == null || str == "" || this.length == 0 || str.length > this.length)
        return false;
    if (this.substring(this.length - str.length) == str)
        return true;
    else
        return false;
    return true;
}
String.prototype.startWith = function (str) {
    if (str == null || str == "" || this.length == 0 || str.length > this.length)
        return false;
    if (this.substr(0, str.length) == str)
        return true;
    else
        return false;
    return true;
}
/******************** end of  string 的相关操作扩展 ****************************/

//功能介绍：检查第一个日期是否小于第二个日期
//参数说明：要检查的字符串(YYYY-MM-DD)
//返回值：false:不是 true:是
function datecompare(strDate1, strDate2) {
    //var  nYear2,   nMonth2,   nDay2, nMonth1,nDay1,nYear1;
    var nYear1 = strDate1.substr(0, 4);
    var nMonth1 = strDate1.substr(5, 2);
    var nDay1 = strDate1.substr(8, 2);
    var nYear2 = strDate2.substr(0, 4);
    var nMonth2 = strDate2.substr(5, 2);
    var nDay2 = strDate2.substr(8, 2);
    if (nYear1 > nYear2) {
        return false;
    }
    if (nYear1 == nYear2) {
        if (nMonth1 == nMonth2) {
            if (nDay1 >= nDay2)
                return false;
        }
        if (nMonth1 > nMonth2) {
            return false;
        }
    }
    return true;
}

/*******************************************************************************
 * 功能: 将日期转换成大写
 * 输入: 例：2009-10-11
 * 输出: 例：二零零九年十月十一日
 ******************************************************************************/
var chinese = ['〇', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
var len = ['十'];
var ydm = ['年', '月', '日'];
function num2chinese(s) {
    //将单个数字转成中文.
    s = "" + s;
    slen = s.length;
    var result = "";
    for (var i = 0; i < slen; i++) {
        result += chinese[s.charAt(i)];
    }
    return result;
}




/*
 函数：格式化日期
 参数：formatStr-格式化字符串
 d：将日显示为不带前导零的数字，如1
 dd：将日显示为带前导零的数字，如01
 ddd：将日显示为缩写形式，如Sun
 dddd：将日显示为全名，如Sunday
 M：将月份显示为不带前导零的数字，如一月显示为1
 MM：将月份显示为带前导零的数字，如01
 MMM：将月份显示为缩写形式，如Jan
 MMMM：将月份显示为完整月份名，如January
 yy：以两位数字格式显示年份
 yyyy：以四位数字格式显示年份
 h：使用12小时制将小时显示为不带前导零的数字，注意||的用法
 hh：使用12小时制将小时显示为带前导零的数字
 H：使用24小时制将小时显示为不带前导零的数字
 HH：使用24小时制将小时显示为带前导零的数字
 m：将分钟显示为不带前导零的数字
 mm：将分钟显示为带前导零的数字
 s：将秒显示为不带前导零的数字
 ss：将秒显示为带前导零的数字
 l：将毫秒显示为不带前导零的数字
 ll：将毫秒显示为带前导零的数字
 tt：显示am/pm
 TT：显示AM/PM
 返回：格式化后的日期
 */
Date.prototype.format = function (formatStr) {
    var date = this;
    /*
     函数：填充0字符
     参数：value-需要填充的字符串, length-总长度
     返回：填充后的字符串
     */
    var zeroize = function (value, length) {
        if (!length) {
            length = 2;
        }
        value = new String(value);
        for (var i = 0, zeros = ''; i < (length - value.length); i++) {
            zeros += '0';
        }
        return zeros + value;
    };
    return formatStr.replace(/"[^"]*"|'[^']*'|\b(?:d{1,4}|M{1,4}|yy(?:yy)?|([hHmstT])\1?|[lLZ])\b/g, function ($0) {
        switch ($0) {
            case 'd':
                return date.getDate();
            case 'dd':
                return zeroize(date.getDate());
            case 'ddd':
                return ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'][date.getDay()];
            case 'dddd':
                return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][date.getDay()];
            case 'M':
                return date.getMonth() + 1;
            case 'MM':
                return zeroize(date.getMonth() + 1);
            case 'MMM':
                return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][date.getMonth()];
            case 'MMMM':
                return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][date.getMonth()];
            case 'yy':
                return new String(date.getFullYear()).substr(2);
            case 'yyyy':
                return date.getFullYear();
            case 'h':
                return date.getHours() % 12 || 12;
            case 'hh':
                return zeroize(date.getHours() % 12 || 12);
            case 'H':
                return date.getHours();
            case 'HH':
                return zeroize(date.getHours());
            case 'm':
                return date.getMinutes();
            case 'mm':
                return zeroize(date.getMinutes());
            case 's':
                return date.getSeconds();
            case 'ss':
                return zeroize(date.getSeconds());
            case 'l':
                return date.getMilliseconds();
            case 'll':
                return zeroize(date.getMilliseconds());
            case 'tt':
                return date.getHours() < 12 ? 'am' : 'pm';
            case 'TT':
                return date.getHours() < 12 ? 'AM' : 'PM';
        }
    });
}


Date.prototype.format = function (format) {
    var o = {
        "M+": this.getMonth() + 1, //month
        "d+": this.getDate(), //day
        "h+": this.getHours(), //hour
        "m+": this.getMinutes(), //minute
        "s+": this.getSeconds(), //second
        "q+": Math.floor((this.getMonth() + 3) / 3), //quarter
        "S": this.getMilliseconds() //millisecond
    }
    if (/(y+)/.test(format)) format = format.replace(RegExp.$1,
        (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)if (new RegExp("(" + k + ")").test(format))
        format = format.replace(RegExp.$1,
            RegExp.$1.length == 1 ? o[k] :
                ("00" + o[k]).substr(("" + o[k]).length));
    return format;
}

