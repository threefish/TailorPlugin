try {
    include("common.js");
    println("_____index.js______");
    var request = fetcher.request;
    //封装获取方式
    request.url = "http://www.ifeng.com/";
    //返回Dom文档
    var dom = fetch.dom(request, "utf-8");
    var show_html= dom.getElementById("viceNav").innerHTML;
} catch (e) {
    var szLocation = fetcher.request.url;
    var szMessage = e.name + ": " + e.message + "\n at (" + e.fileName + ":" + e.lineNumber + ")";
    log.error(szLocation, szMessage);
    println(szMessage);
}
