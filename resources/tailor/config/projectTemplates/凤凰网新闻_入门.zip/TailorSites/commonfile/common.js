/**
 * Created by HuangChuan on 2015/1/15.
 */
//引入服务器配置
include("common.server.js");
//引入工具包
include("common.util.js");